<?php
/**
 * reg-post-types.php
 *
 * TK Register custom post types and taxonomies
 *
 * 1. Custom Post Types
 * 2. Custom Taxonomies
 */

/**
 * ----------------------------------
 * 1. CUSTOM POST TYPES
 * ----------------------------------
 */
if ( !function_exists( 'tk_add_custom_post_types' ) ) {
    function tk_add_custom_post_types() {
        // Gallery post type
        $labels = array(
            'name'               => __( 'Album', 'tkposttypes' ),
            'singular_name'      => __( 'Album', 'tkposttypes' ),
            'add_new'            => __( 'Add New', 'tkposttypes' ),
            'add_new_item'       => __( 'Add New Album', 'tkposttypes' ),
            'edit_item'          => __( 'Edit Album', 'tkposttypes' ),
            'new_item'           => __( 'New Album', 'tkposttypes' ),
            'all_items'          => __( 'All Albums', 'tkposttypes' ),
            'view_item'          => __( 'View this Album', 'tkposttypes' ),
            'search_items'       => __( 'Search Albums', 'tkposttypes' ),
            'not_found'          => __( 'No Albums', 'tkposttypes' ),
            'not_found_in_trash' => __( 'No Albums in Trash', 'tkposttypes' ),
            'parent_item_colon'  => '',
            'menu_name'          => __( 'Albums', 'tkposttypes' ),
        ); // end $labels
        $args = array(
            'labels'              => $labels,
            'public'              => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'show_ui'             => true,
            'query_var'           => true,
            'capability_type'     => 'post',
            'rewrite'             => array( 'slug' => 'album' ),
            'hierarchical'        => false,
            'menu_position'       => null,
            'has_archive'         => true,
            'menu_icon'           => 'dashicons-media-audio',
            'supports'            => array( 'title', 'editor', 'thumbnail', 'comments' )
        ); // end $args
        register_post_type( 'album', $args );

        // Events post type
        $labels = array(
            'name'               => __( 'Events', 'tkposttypes' ),
            'singular_name'      => __( 'Event', 'tkposttypes' ),
            'add_new'            => __( 'Add New', 'tkposttypes' ),
            'add_new_item'       => __( 'Add New Event', 'tkposttypes' ),
            'edit_item'          => __( 'Edit Event', 'tkposttypes' ),
            'new_item'           => __( 'New Event', 'tkposttypes' ),
            'all_items'          => __( 'All Events', 'tkposttypes' ),
            'view_item'          => __( 'View this Event', 'tkposttypes' ),
            'search_items'       => __( 'Search Events', 'tkposttypes' ),
            'not_found'          => __( 'No Events', 'tkposttypes' ),
            'not_found_in_trash' => __( 'No Events in Trash', 'tkposttypes' ),
            'parent_item_colon'  => '',
            'menu_name'          => __( 'Events', 'tkposttypes' ),
        ); // end $labels
        $args = array(
            'labels'              => $labels,
            'public'              => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'show_ui'             => true,
            'query_var'           => true,
            'capability_type'     => 'post',
            'rewrite'             => array( 'slug' => 'event' ),
            'hierarchical'        => false,
            'menu_position'       => null,
            'has_archive'         => true,
            'menu_icon'           => 'dashicons-calendar-alt',
            'supports'            => array( 'title', 'editor', 'thumbnail', 'comments', 'post-formats' ),
            'taxonomies'          => array( 'ct_events' ),
        ); // end $args
        register_post_type( 'event', $args );

        // Gallery post type
        $labels = array(
            'name'               => __( 'Gallery', 'tkposttypes' ),
            'singular_name'      => __( 'Gallery', 'tkposttypes' ),
            'add_new'            => __( 'Add New', 'tkposttypes' ),
            'add_new_item'       => __( 'Add New Gallery', 'tkposttypes' ),
            'edit_item'          => __( 'Edit Gallery', 'tkposttypes' ),
            'new_item'           => __( 'New Gallery', 'tkposttypes' ),
            'all_items'          => __( 'All Gallery', 'tkposttypes' ),
            'view_item'          => __( 'View this Gallery', 'tkposttypes' ),
            'search_items'       => __( 'Search Gallery', 'tkposttypes' ),
            'not_found'          => __( 'No Gallery', 'tkposttypes' ),
            'not_found_in_trash' => __( 'No Gallery in Trash', 'tkposttypes' ),
            'parent_item_colon'  => '',
            'menu_name'          => __( 'Gallery', 'tkposttypes' ),
        ); // end $labels
        $args = array(
            'labels'              => $labels,
            'public'              => true,
            'exclude_from_search' => false,
            'publicly_queryable'  => true,
            'show_ui'             => true,
            'query_var'           => true,
            'capability_type'     => 'post',
            'rewrite'             => array( 'slug' => 'gallery' ),
            'hierarchical'        => false,
            'menu_position'       => null,
            'has_archive'         => true,
            'menu_icon'           => 'dashicons-images-alt2',
            'supports'            => array( 'title', 'editor', 'thumbnail', 'comments', 'post-formats' ),
            'taxonomies'          => array( 'ct_gallery' ),
        ); // end $args
        register_post_type( 'gallery', $args );


        // Remove rewrite rules and then recreate rewrite rules
        flush_rewrite_rules();
    }
    add_action( 'init', 'tk_add_custom_post_types' );
}


/**
 * ----------------------------------
 * 2. CUSTOM TAXONOMIES
 * ----------------------------------
 */
if ( ! function_exists( 'tk_add_custom_taxonomies' ) ) {
    function tk_add_custom_taxonomies() {

        // Events Categories taxonomy
        $labels = array( 'name' => _x( 'Event Categories', 'taxonomy general name', 'tkposttypes' ),
            'singular_name'     => _x( 'Event Categories', 'taxonomy singular name', 'tkposttypes' ),
            'search_items'      => __( 'Search Event Categories', 'tkposttypes' ),
            'all_items'         => __( 'All Event Categories', 'tkposttypes' ),
            'parent_item'       => __( 'Parent Event Category', 'tkposttypes' ),
            'parent_item_colon' => __( 'Parent Event Category', 'tkposttypes' ),
            'edit_item'         => __( 'Edit Event Category', 'tkposttypes' ),
            'update_item'       => __( 'Update Event Category', 'tkposttypes' ),
            'add_new_item'      => __( 'Add New Event Category', 'tkposttypes' ),
            'new_item_name'     => __( 'New Event Category', 'tkposttypes' ),
            'menu_name'         => __( 'Event Categories', 'tkposttypes' ),
            'popular_items'     => null,
        );

        register_taxonomy( 'ct_events', 'event', array(
            'hierarchical'  => true,
            'show_tagcloud' => false,
            'labels'        => $labels,
            'rewrite'       => array(
                'slug'         => 'event-category',
                'with_front'   => false,
                'hierarchical' => true
            )
        ) );


        // Gallery Categories taxonomy
        $labels = array( 'name' => _x( 'Gallery Categories', 'taxonomy general name', 'tkposttypes' ),
            'singular_name'     => _x( 'Gallery Categories', 'taxonomy singular name', 'tkposttypes' ),
            'search_items'      => __( 'Search Gallery Categories', 'tkposttypes' ),
            'all_items'         => __( 'All Gallery Categories', 'tkposttypes' ),
            'parent_item'       => __( 'Parent Gallery Category', 'tkposttypes' ),
            'parent_item_colon' => __( 'Parent Gallery Category', 'tkposttypes' ),
            'edit_item'         => __( 'Edit Gallery Category', 'tkposttypes' ),
            'update_item'       => __( 'Update Gallery Category', 'tkposttypes' ),
            'add_new_item'      => __( 'Add New Gallery Category', 'tkposttypes' ),
            'new_item_name'     => __( 'New Gallery Category', 'tkposttypes' ),
            'menu_name'         => __( 'Gallery Categories', 'tkposttypes' ),
            'popular_items'     => null,
        );

        register_taxonomy( 'ct_gallery', 'gallery', array(
            'hierarchical'  => true,
            'show_tagcloud' => false,
            'labels'        => $labels,
            'rewrite'       => array(
                'slug'         => 'gallery-category',
                'with_front'   => false,
                'hierarchical' => true
            )
        ) );

    }
    add_action( 'init', 'tk_add_custom_taxonomies', 0 );
}
?>